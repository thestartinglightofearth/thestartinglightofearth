import requests,re,os,random
import socket
def cls():
	os.system(['clear', 'cls'][(os.name == 'nt')])
cls()
try:
	import concurrent.futures
	xxx = True
except:
	from multiprocessing.pool import ThreadPool
	xxx = False
red = '\x1b[31m'
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
RIPON = False
def Ret(x):
	try:
		return raw_input(x)
	except:
		return input(x)
logo = """   _____       _       _         _ _      __ ____ ____ ______ 
  / ____|     | |     | |       | (_)    /_ |___ \___ \____  |
 | (___   __ _| | __ _| |__   __| |_ _ __ | | __) |__) |  / / 
  \___ \ / _` | |/ _` | '_ \ / _` | | '_ \| ||__ <|__ <  / /  
  ____) | (_| | | (_| | | | | (_| | | | | | |___) |__) |/ /   
 |_____/ \__,_|_|\__,_|_| |_|\__,_|_|_| |_|_|____/____//_/                                                              """
print(r+logo+"""\n    {}I Don't Aspect Any Responsibility For Bad Ussage!{}\n\n Author: {}The Black_Phish{}\n Name: {}The Bing BOT{}\n Application: {}Python 2.7 & 3.9 Supported{}\n Chose a Tool:{}\n  1. Bing Weblist Grabber Tool\n  2. Bing Reversip Tool (Unlimited)\n  3. Live IP Check + IP From Domain\n  4. Bing Normal Dorking\n  5. IP Ranger + Ip Live
 """.format(g,y,c,y,c,y,c,m,w))
user_agent_list = [
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36',
 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36',
 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0',
 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:79.0) Gecko/20100101 Firefox/79.0',
 'Mozilla/5.0 (X11; Linux i686; rv:79.0) Gecko/20100101 Firefox/79.0',
 'Mozilla/5.0 (Linux x86_64; rv:79.0) Gecko/20100101 Firefox/79.0',
 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:79.0) Gecko/20100101 Firefox/79.0',
 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:79.0) Gecko/20100101 Firefox/79.0',
 'Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:79.0) Gecko/20100101 Firefox/79.0',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36 OPR/70.0.3728.95',
 'Mozilla/5.0 (Windows NT 10.0; WOW64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36 OPR/70.0.3728.95',
 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36 OPR/70.0.3728.95',
 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36 OPR/70.0.3728.95',
 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36',
 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36',
 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36',
 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.61 Safari/537.36',
 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.79 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0',
 'Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:73.0) Gecko/20100101 Firefox/73.0',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:71.0) Gecko/20100101 Firefox/71.0',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:77.0) Gecko/20100101 Firefox/77.0',
 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)',
 'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E; .NET CLR 2.0.50727; .NET CLR 3.0.30729; .NET CLR 3.5.30729; rv:11.0) like Gecko',
 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36']
try:
	domain = open("domain.txt","r").read().splitlines()
except:
	domain = ['co.in', 'co.uk', 'in', 'pk', 'co.pk', 'co.org', 'org', 'com', 'uk', 'bd', 'net', 'ac', 'ad', 'ae', 'af', 'ag', 'ai', 'al', 'am', 'an', 'ao', 'aq', 'ar', 'as', 'at', 'au', 'aw', 'ax', 'az', 'ba', 'bb', 'bd', 'be', 'bf', 'bg', 'bh', 'bi', 'bj', 'bm', 'bn', 'bo', 'br', 'bs', 'bt', 'bv', 'bw', 'by', 'bz', 'ca', 'cc', 'cd', 'cf', 'cg', 'ch', 'ci', 'ck', 'cl', 'cm', 'cn', 'co', 'cr', 'cu', 'cv', 'cx', 'cy', 'cz', 'de', 'dj', 'dk', 'dm', 'do', 'dz', 'ec', 'ee', 'eg', 'eh', 'er', 'es', 'et', 'eu', 'fi', 'fj', 'fk', 'fm', 'fo', 'fr', 'ga', 'gb', 'gd', 'ge', 'gf', 'gg', 'gh', 'gi', 'gl', 'gm', 'gn', 'gp', 'gq', 'gr', 'gs', 'gt', 'gu', 'gw', 'gy', 'hk', 'hm', 'hn', 'hr', 'ht', 'hu', 'id', 'ie', 'il', 'im', 'in', 'io', 'iq', 'is', 'it', 'je', 'jm', 'jo', 'jp', 'ke', 'kg', 'kh', 'ki', 'km', 'kn', 'kp', 'kr', 'kw', 'ky', 'kz', 'la', 'lb', 'lc', 'li', 'lk', 'lr', 'ls', 'lt', 'lu', 'lv', 'ly', 'ma', 'mc', 'md', 'me', 'mg', 'mh', 'mk', 'ml', 'mm', 'mn', 'mo', 'mp', 'mq', 'mr', 'ms', 'mt', 'mu', 'mv', 'mw', 'mx', 'my', 'mz', 'na', 'nc', 'ne', 'nf', 'ng', 'ni', 'nl', 'no', 'np', 'nr', 'nu', 'nz', 'om', 'pa', 'pe', 'pf', 'pg', 'ph', 'pk', 'pl', 'pm', 'pn', 'pr', 'ps', 'pt', 'pw', 'py', 'qa', 're', 'ro', 'rs', 'ru', 'rw', 'sa', 'sb', 'sc', 'sd', 'se', 'sg', 'sh', 'si', 'sj', 'sk', 'sl', 'sm', 'sn', 'so', 'sr', 'st', 'su', 'sv', 'sy', 'sz', 'tc', 'td', 'tf', 'tg', 'th', 'tj', 'tk', 'tl', 'tm', 'tn', 'to', 'tp', 'tr', 'tt', 'tv', 'tw', 'tz', 'ua', 'ug', 'uk', 'um', 'us', 'uy', 'uz', 'va', 'vc', 've', 'vg', 'vi', 'vn', 'vu', 'wf', 'ws', 'ye', 'yt', 'za', 'zm', 'zw', 'com', 'net', 'org', 'biz', 'gov', 'mil', 'edu', 'info', 'int', 'tel', 'app', 'gay', 'tech', 'dev', 'online', 'shop', 'site', 'club', 'design', 'space', 'academy', 'accountant', 'accountants', 'actor', 'adult', 'ae.org', 'africa', 'agency', 'apartments', 'com.ar', 'archi', 'art', 'asia', 'associates', 'attorney', 'com.au', 'id.au', 'net.au', 'org.au', 'auction', 'band', 'bar', 'bargains', 'bayern', 'beauty', 'beer', 'berlin', 'best', 'bet', 'bid', 'bike', 'bingo', 'bio', 'black', 'blog', 'blue', 'boats', 'boston', 'boutique', 'br.com', 'brussels', 'build', 'builders', 'business', 'buzz', 'cab', 'cafe', 'cam', 'camera', 'camp', 'capetown', 'capital', 'cards', 'care', 'career', 'careers', 'casa', 'cash', 'casino', 'catering', 'center', 'charity', 'chat', 'cheap', 'church', 'city', 'claims', 'cleaning', 'click', 'clinic', 'clothing', 'cloud', 'cn.com', 'coach', 'codes', 'coffee', 'college', 'cologne', 'community', 'company', 'compare', 'computer', 'condos', 'construction', 'consulting', 'contact', 'contractors', 'cooking', 'cool', 'country', 'coupons', 'courses', 'credit', 'cricket', 'cruises', 'cyou', 'dance', 'date', 'dating', 'deals', 'degree', 'delivery', 'democrat', 'dental', 'dentist', 'diamonds', 'digital', 'direct', 'directory', 'discount', 'doctor', 'dog', 'domains', 'download', 'durban', 'earth', 'eco', 'education', 'email', 'energy', 'engineer', 'engineering', 'enterprises', 'equipment', 'estate', 'eu.com', 'events', 'exchange', 'expert', 'exposed', 'express', 'fail', 'faith', 'family', 'fan', 'fans', 'farm', 'fashion', 'finance', 'financial', 'fish', 'fishing', 'fit', 'fitness', 'flights', 'florist', 'football', 'forsale', 'foundation', 'fun', 'fund', 'furniture', 'futbol', 'fyi', 'gallery', 'games', 'garden', 'gift', 'gifts', 'gives', 'glass', 'global', 'gold', 'golf', 'graphics', 'gratis', 'green', 'gripe', 'group', 'guide', 'guru', 'hair', 'hamburg', 'haus', 'health', 'healthcare', 'help', 'hockey', 'holdings', 'holiday', 'homes', 'horse', 'hospital', 'host', 'house', 'how', 'immo', 'immobilien', 'industries', 'ink', 'institute', 'insure', 'international', 'investments', 'jetzt', 'jewelry', 'joburg', 'jpn.com', 'kaufen', 'kim', 'kitchen', 'kiwi', 'koeln', 'kyoto', 'land', 'lat', 'lawyer', 'lease', 'legal', 'lgbt', 'life', 'lighting', 'limited', 'limo', 'link', 'live', 'loan', 'loans', 'lol', 'london', 'love', 'ltd', 'luxe', 'maison', 'management', 'market', 'marketing', 'mba', 'media', 'melbourne', 'memorial', 'men', 'menu', 'miami', 'mobi', 'moda', 'moe', 'mom', 'money', 'mortgage', 'nagoya', 'name', 'network', 'news', 'ngo', 'ninja', 'nyc', 'ac.nz', 'org.nz', 'kiwi.nz', 'net.nz', 'school.nz', 'gen.nz', 'geek.nz', 'co.nz', 'maori.nz', 'okinawa', 'one', 'onl', 'organic', 'osaka', 'page', 'paris', 'partners', 'parts', 'party', 'pet', 'photo', 'photography', 'photos', 'pics', 'pictures', 'pink', 'pizza', 'place', 'plumbing', 'plus', 'poker', 'porn', 'press', 'pro', 'productions', 'promo', 'properties', 'pub', 'qpon', 'quebec', 'quest', 'racing', 'realestate', 'recipes', 'red', 'rehab', 'reise', 'reisen', 'rent', 'rentals', 'repair', 'report', 'republican', 'rest', 'restaurant', 'review', 'reviews', 'rip', 'rocks', 'rodeo', 'ru.com', 'run', 'ryukyu', 'sa.com', 'sale', 'salon', 'sarl', 'com.sb', 'school', 'schule', 'science', 'scot', 'select', 'services', 'sexy', 'com.sg', 'shiksha', 'shoes', 'shopping', 'show', 'singles', 'ski', 'skin', 'soccer', 'social', 'software', 'solar', 'solutions', 'soy', 'store', 'stream', 'studio', 'study', 'style', 'supplies', 'supply', 'support', 'surf', 'surgery', 'sx', 'sydney', 'systems', 'taipei', 'tattoo', 'tax', 'taxi', 'team', 'technology', 'tennis', 'theater', 'tienda', 'tips', 'tires', 'today', 'tokyo', 'tools', 'top', 'tours', 'town', 'toys', 'trade', 'trading', 'training', 'tube', 'org.uk', 'me.uk', 'uk.com', 'university', 'uno', 'us.com', 'vacations', 'vegas', 'ventures', 'vet', 'viajes', 'video', 'villas', 'vin', 'vip', 'vision', 'vlaanderen', 'vodka', 'vote', 'voyage', 'wales', 'wang', 'watch', 'webcam', 'website', 'wedding', 'wien', 'wiki', 'win', 'wine', 'work', 'works', 'world', 'wtf', 'xyz', 'yoga', 'yokohama', 'co.za', 'za.com', 'zone']
def rez(url,exploit,n):
	if "|" in exploit:
		arr = exploit.split("|")
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+r+" [NO]")
	else:
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+exploit+": "+w+url+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+exploit+": "+w+url+r+" [NO]")
def SpeedX(check,list,th):
	if xxx == True:
		try:
			with concurrent.futures.ThreadPoolExecutor(int(th)) as executor:
				executor.map(check,list)
		except Exception as e:
			print(e)
	else:
		pool = ThreadPool(int(th))
		pool.map(check,list)
		pool.close()
		pool.join()
def saved(x,y):
	i = x
	i = i.replace("http://","")
	i = i.replace("https://","")
	i = i.replace("www.","")
	i = i.split("/")
	i = i[0]
	try:
		m = open(y,"r").read()
	except:
		open(y,"w")
		m = open(y,"r").read()
	if i in m:
		if "." in i:
			rez(x,"Added","1h")
		pass
	else:
		if "." in x:
			rez(x,"Added","1")
			open(y,"a").write(x+"\n")
def check(url):
	pdf = ".pdf"
	string = "." in url
	try:
		file = open(filename,"r").read()
	except:
		open(filename,"w")
		file = open(filename,"r").read()
	if url in file or pdf in url or string == False:
		if "." in url:
			rez(url,"Added","41")
	else:
		file = open(filename,"a")
		file.write(url+"\n")
		file.close()
		rez(url,"Added","1")
def ipdorker(dork):
	headers = {'user-agent': random.choice(user_agent_list)+str(random.choice(range(1000)))}
	okkk = dork
	first = 0
	try:
		for i in range(int(page2)):
			first = first+50
			url = "http://www.bing.com/search?q=ip%3A%22"+okkk+"%22&count=1000&first="+str(first)
			result = requests.get(url,headers=headers,timeout=50)
			result = result.content.decode('utf-8')
			patern = r'<a href="(.*?)"'
			ok = re.findall(patern,result)
			for i in ok:
				i = i.replace("<strong>","")
				i = i.replace("</strong>","")
				i = i.replace("http://","")
				i = i.replace("https://","")
				i = i.replace("www.","")
				i = i.split("/")
				i = i[0]
				if "go.microsoft.com" in i or "javascript:" in i or i == "\n":
					pass
				else:
					if "." in i:
						check(i)						
	except Exception as e:
		print(e)
		ipdorker(dork)
def ip(x):
	try:
		socket.setdefaulttimeout(10)
		url = socket.gethostbyname(x)
	except Exception as e:
		rez(x,"LIVED","n")
		return 5
	try:
		if RIPON == False:
			savefile = filename
		else:
			savefile = "all-ip.txt"
		file = open(savefile,"r").read()
	except:
		open(savefile,"w")
		file = open(savefile,"r").read()
	if url in file:
		pass
	else:
		file = open(savefile,"a")
		file.write(url+"\n")
		file.close()
		rez(url,"LIVED","1")
		if RIPON == True:
			ipdorker(url)
def liveips(ip):
	try:
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		socket.setdefaulttimeout(5)
		m = s.connect_ex((ip,80))
		if str(m) == "0":
			file = open(filename,"a")
			file.write(ip+"\n")
			file.close()
			rez(ip,"LIVED","1")
		else:
			rez(ip,"LIVED","g1")
	except Exception as e:
		rez(ip,"LIVED","n")
		return 5
def bing(dork):
	headers = {'user-agent': random.choice(user_agent_list)+str(random.choice(range(1000)))}
	for dom in domain:
		okkk = dork.strip()+" site:."+dom
		first = 0
		try:
			for i in range(int(page1)):
				first = first+50
				params = {'q': okkk, 'count': '1000','first':first}
				url = "http://www.bing.com/search"
				result = requests.get(url,params=params,headers=headers,timeout=10)
				result = result.content.decode('utf-8')
				patern = r'<a href="(.*?)"'
				ok = re.findall(patern,result)
				for i in ok:
					if "go.microsoft.com" in i or "javascript:" in i or i == "\n":
						pass
					else:
						if RIPON == True:
							i = i.replace("<strong>","")
							i = i.replace("</strong>","")
							i = i.replace("http://","")
							i = i.replace("https://","")
							i = i.replace("www.","")
							i = i.split("/")
							i = i[0]
							if "go.microsoft.com" in i or "javascript:" in i or i == "\n":
								pass
							else:
								if "." in i:
									check(i)
									ip(i)
						else:
							saved(i,filename)
		except Exception as e:
			print(e)
			bing(dork)
def IpRanger(ipx):
	store = ipx.split(".")[0]+"."+ipx.split(".")[1]
	for i in range(1,256):
		for y in range(1,256):
			liveips(str(store+"."+str(i)+"."+str(y)))
try:
	cmd = Ret(g+" [{}root{}@{}salahdin{}:{}~{}]{}# {}".format(g,r,y,g,c,g,m,r))
except Exception as e:
	print(e)
	exit()
if cmd == "1":
	RIPON = True
	try:
		cls()
		print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}Bing Weblist Grabber\n""".format(y,c,y,c))
		dorks = Ret(g+" DorkList"+w+":"+c+"~"+m+"# "+r)
		page1 = Ret(g+" Page Dork"+w+":"+c+"~"+m+"# "+r)
		page2 = Ret(g+" Page Reversip"+w+":"+c+"~"+m+"# "+r)
		filename = Ret(g+" Save File"+w+":"+c+"~"+m+"# "+r)
		th = Ret(g+" Threads"+w+":"+c+"~"+m+"# "+r)
		dork = open(dorks,"r").read().splitlines()
		cls()
		SpeedX(bing,dork,th)
	except Exception as e:
		print(e)
		exit()
if cmd == "2":
	try:
		cls()
		print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}Bing Unlimited Reversip\n""".format(y,c,y,c))
		dorks = Ret(g+" IpList"+w+":"+c+"~"+m+"# "+r)
		page2 = Ret(g+" Page Reversip"+w+":"+c+"~"+m+"# "+r)
		filename = Ret(g+" Save File"+w+":"+c+"~"+m+"# "+r)
		th = Ret(g+" Threads"+w+":"+c+"~"+m+"# "+r)
		dork = open(dorks,"r").read().splitlines()
		cls()
		SpeedX(ipdorker,dork,th)
	except Exception as e:
		print(e)
		exit()
if cmd == "3":
	try:
		cls()
		print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}Grab Weblist To Ip\n""".format(y,c,y,c))
		dorks = Ret(g+" EnterList"+w+":"+c+"~"+m+"# "+r)
		filename = Ret(g+" Save File"+w+":"+c+"~"+m+"# "+r)
		th = Ret(g+" Threads"+w+":"+c+"~"+m+"# "+r)
		dork = open(dorks,"r").read().splitlines()
		cls()
		SpeedX(ip,dork,th)		
	except Exception as e:
		print(e)
		exit()
if cmd == "4":
	try:
		cls()
		print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}Bing Basic Dorker\n""".format(y,c,y,c))
		dorks = Ret(g+" DorkList"+w+":"+c+"~"+m+"# "+r)
		page1 = Ret(g+" Page Dork"+w+":"+c+"~"+m+"# "+r)
		filename = Ret(g+" Save File"+w+":"+c+"~"+m+"# "+r)
		th = Ret(g+" Threads"+w+":"+c+"~"+m+"# "+r)
		dork = open(dorks,"r").read().splitlines()
		cls()
		SpeedX(bing,dork,th)
	except Exception as e:
		print(e)
		exit()
if cmd == "5":
	try:
		cls()
		print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}Ip Ranger + Live Checker\n""".format(y,c,y,c))
		dorks = Ret(g+" IpList"+w+":"+c+"~"+m+"# "+r)
		filename = Ret(g+" Save File"+w+":"+c+"~"+m+"# "+r)
		th = Ret(g+" Threads"+w+":"+c+"~"+m+"# "+r)
		dork = open(dorks,"r").read().splitlines()
		cls()
		SpeedX(IpRanger,dork,th)
	except Exception as e:
		print(e)
		exit()
else:
	cls()
	print(g+" [+] Tool Closed Successfully [+]")