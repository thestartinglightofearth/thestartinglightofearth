###################################																			 #
#																	 		#
#	Author : Me Black_Phish				  			#
#	Software: Python 3.7									#
#	Module: Requests, Coloram						#
#														 					#
# 																			#
##################################

Termux Commands:
	
	 pkg install python
	 pip install requests
	 pip install colorama 
